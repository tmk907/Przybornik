﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;

namespace $rootnamespace$
{
    public class $fileinputname$Query : IRequest<$fileinputname$Response>
    {
    }

    public class $fileinputname$Response
    {
    }

    public class $fileinputname$QueryHandler : IRequestHandler<$fileinputname$Query, $fileinputname$Response>
    {
        public Task<$fileinputname$Response> Handle($fileinputname$Query request, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
