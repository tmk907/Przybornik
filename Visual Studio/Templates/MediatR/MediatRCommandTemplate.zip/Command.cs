﻿using System;
using System.Collections.Generic;
using MediatR;

namespace $rootnamespace$
{
    public class $fileinputname$Command : IRequest
    {
        
    }
}
