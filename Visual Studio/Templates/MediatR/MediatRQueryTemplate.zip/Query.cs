﻿using System;
using System.Collections.Generic;
using MediatR;

namespace $rootnamespace$
{
    public class $fileinputname$Query : IRequest<$fileinputname$Response>
    {
    }
}
