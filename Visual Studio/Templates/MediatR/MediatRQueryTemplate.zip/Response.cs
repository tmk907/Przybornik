﻿using System;
using System.Collections.Generic;

namespace $rootnamespace$
{
    public class $fileinputname$Response
    {
    }
}
